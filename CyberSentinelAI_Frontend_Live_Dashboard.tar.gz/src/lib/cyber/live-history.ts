import type { AnalysisResult } from "@/lib/cyber/types";

export type LiveAnalysis = Pick<AnalysisResult,
  "requestId" | "createdAt" | "predictedLabel" | "predictedDisplay" | "isAttack" |
  "threatLevel" | "confidence" | "featureCount" | "processingMs" | "topContributingFeatures" |
  "explanationSource" | "reviewRequired" | "modelScore" | "confidenceThreshold"
>;

const KEY = "cybersentinel:live-analyses:v1";
const UPDATED_EVENT = "cybersentinel:analysis-updated";

export function readLiveAnalyses(): LiveAnalysis[] {
  if (typeof window === "undefined") return [];
  try {
    const parsed = JSON.parse(window.localStorage.getItem(KEY) || "[]");
    return Array.isArray(parsed) ? parsed as LiveAnalysis[] : [];
  } catch {
    return [];
  }
}

export function recordLiveAnalysis(result: AnalysisResult): void {
  if (typeof window === "undefined") return;
  const item: LiveAnalysis = {
    requestId: result.requestId,
    createdAt: result.createdAt,
    predictedLabel: result.predictedLabel,
    predictedDisplay: result.predictedDisplay,
    isAttack: result.isAttack,
    threatLevel: result.threatLevel,
    confidence: result.confidence,
    featureCount: result.featureCount,
    processingMs: result.processingMs,
    topContributingFeatures: result.topContributingFeatures,
    explanationSource: result.explanationSource,
    reviewRequired: Boolean((result as AnalysisResult & { reviewRequired?: boolean }).reviewRequired),
    modelScore: Number((result as AnalysisResult & { modelScore?: number }).modelScore ?? result.confidence),
    confidenceThreshold: (result as AnalysisResult & { confidenceThreshold?: number }).confidenceThreshold,
  };
  const next = [item, ...readLiveAnalyses()].filter((entry) => entry.requestId !== item.requestId).slice(0, 100);
  window.localStorage.setItem(KEY, JSON.stringify(next));
  window.dispatchEvent(new Event(UPDATED_EVENT));
}

export function subscribeLiveAnalyses(callback: () => void): () => void {
  if (typeof window === "undefined") return () => {};
  window.addEventListener(UPDATED_EVENT, callback);
  window.addEventListener("storage", callback);
  return () => {
    window.removeEventListener(UPDATED_EVENT, callback);
    window.removeEventListener("storage", callback);
  };
}
