// GET /api/samples
// Returns the synthetic sample traffic profiles available in the analyzer.

import { NextResponse } from "next/server";
import { SAMPLE_PROFILES } from "@/lib/cyber/samples";

export const runtime = "nodejs";

export async function GET() {
  return NextResponse.json(SAMPLE_PROFILES);
}
